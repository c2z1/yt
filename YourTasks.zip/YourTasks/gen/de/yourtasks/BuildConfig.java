/** Automatically generated file. DO NOT MODIFY */
package de.yourtasks;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}