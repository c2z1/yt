package de.yourtasks.utils;

public class Service {
	
	public static void userMessage(String string) {
		// TODO Auto-generated method stub
		
	}
}
