package de.yourtasks.utils;

public interface Converter<S, T> {
	T convert(S obj);
}
