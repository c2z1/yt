package de.yourtasks.utils;


public interface DataChangeListener<T> {

	void dataChanged();
}
