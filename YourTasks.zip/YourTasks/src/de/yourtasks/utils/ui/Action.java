package de.yourtasks.utils.ui;

import android.graphics.drawable.Drawable;
import android.view.View;

public abstract class Action<T> {
	public Action() {
	}
	public abstract void actionPerformed(View btn, T item);
	
	public abstract String getName(T item);
	
	public abstract Drawable getIcon(T item);
}